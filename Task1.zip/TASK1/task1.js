const firebaseConfig = {
  apiKey: "AIzaSyDSC-j-2o4pfdMy7sb2gHnO9Ua4sLoZh2w",
  authDomain: "login-registration-task-1.firebaseapp.com",
  projectId: "login-registration-task-1",
  storageBucket: "login-registration-task-1.appspot.com",
  messagingSenderId: "309212826382",
  appId: "1:309212826382:web:85f95ef6f301481e30655f"
};


firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function showRegister() {
  document.getElementById('register-container').style.display = 'block';
  document.getElementById('login-container').style.display = 'none';
}

function showLogin() {
  document.getElementById('register-container').style.display = 'none';
  document.getElementById('login-container').style.display = 'block';
}

function registeration() {
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  
  auth.createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
          alert('Registration Successful');
          showLogin();
      })
      .catch((error) => {
          alert(error.message);
      });
}

function login() {

const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  
  auth.signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
          alert('Login Successful');
      })
      .catch((error) => {
          alert(error.message);
      });
}